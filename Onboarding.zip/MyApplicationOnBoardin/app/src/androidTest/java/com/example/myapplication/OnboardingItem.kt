package com.example.myapplication

import android.widget.ImageView

data class OnboardingItem (
    val onboardingImage: Int,
        )