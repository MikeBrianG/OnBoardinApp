package com.example.myapplication

import android.view.View
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView

class OnboardingItemAdapter {
    inner class OnboardingItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        private val imageOnboarding = view.findViewById<ImageView>(R.id.)

    }
}