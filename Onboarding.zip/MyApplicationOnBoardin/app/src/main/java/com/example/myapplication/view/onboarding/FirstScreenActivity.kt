package com.example.myapplication.view.onboarding

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import com.example.myapplication.R
import com.example.myapplication.databinding.ActivityFirstScreenBinding

class FirstScreenActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFirstScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val view = ActivityFirstScreenBinding.inflate(LayoutInflater.from(this))
        binding = ActivityFirstScreenBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_first_screen)

    }
}